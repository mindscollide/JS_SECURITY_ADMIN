import React, { useState } from "react";
import { Container, Col, Row } from "react-bootstrap";
import { TextField, Button, Table, Paper } from "../../components/elements";
import { Select } from "antd";
import DatePicker from "react-multi-date-picker";
import "./Userreport.css";

const Userreport = () => {
  const [value, setValue] = useState(new Date());

  const [startDateProps, setStartDateProps] = useState({
    value: new Date(),
    format: "MM-DD-YYYY",
    onChange: (date) => console.log(date.format()),
  });

  const [endDateProps, setEndDateProps] = useState({
    value: new Date(),
    format: "MM-DD-YYYY",
    onChange: (date) => console.log(date.format()),
  });

  // state for select Role
  const [selectRoleReport, setSelectRoleReport] = useState([]);

  //state for userReports fields
  const [userReport, setUserReport] = useState({
    loginID: {
      value: "",
      errorMessage: "",
      errorStatus: false,
    },
    firstName: {
      value: "",
      errorMessage: "",
      errorStatus: false,
    },
    lastName: {
      value: "",
      errorMessage: "",
      errorStatus: false,
    },
    selectRole: 0,
  });

  // onchange handler for user report
  const userReportHandler = (e) => {
    let name = e.target.name;
    let value = e.target.value;

    if (name === "loginID" && value !== "") {
      console.log(value, "loginIDloginIDloginID");
      let valueCheck = value.replace(/[^\d]/g, "");
      if (valueCheck !== "") {
        setUserReport({
          ...userReport,
          loginID: {
            value: valueCheck.trimStart(),
            errorMessage: "",
            errorStatus: false,
          },
        });
      }
    } else if (name === "loginID" && value === "") {
      setUserReport({
        ...userReport,
        loginID: { value: "", errorMessage: "", errorStatus: false },
      });
    }

    if (name === "firstName" && value !== "") {
      let valueCheck = value.replace(/[^a-zA-Z ]/g, "");
      if (valueCheck !== "") {
        setUserReport({
          ...userReport,
          firstName: {
            value: valueCheck.trimStart(),
            errorMessage: "",
            errorStatus: false,
          },
        });
      }
    } else if (name === "firstName" && value === "") {
      setUserReport({
        ...userReport,
        firstName: { value: "", errorMessage: "", errorStatus: false },
      });
    }

    if (name === "lastName" && value !== "") {
      let valueCheck = value.replace(/[^a-zA-Z ]/g, "");
      if (valueCheck !== "") {
        setUserReport({
          ...userReport,
          lastName: {
            value: valueCheck.trimStart(),
            errorMessage: "",
            errorStatus: false,
          },
        });
      }
    } else if (name === "lastName" && value === "") {
      setUserReport({
        ...userReport,
        lastName: { value: "", errorMessage: "", errorStatus: false },
      });
    }
  };

  //reset handler
  const resetHandler = () => {
    setUserReport({
      ...userReport,
      loginID: {
        value: "",
      },
      firstName: {
        value: "",
      },
      lastName: {
        value: "",
      },

      selectRole: 0,
    });

    setStartDateProps({
      ...startDateProps,
      value: "",
    });

    setEndDateProps({
      ...endDateProps,
      value: "",
    });
  };

  // onchange handler for user Report select role
  const reportSelectRoleHandler = async (selectedRole) => {
    setUserReport({
      ...userReport,
      selectRole: selectedRole.value,
    });
  };

  return (
    <>
      <Container className="report-user-container">
        <Row>
          <Col lg={12} md={12} sm={12} className="d-flex justify-content-start">
            <label className="report-user-label">User Reports</label>
          </Col>
        </Row>

        <Paper className="span-user-color">
          <Row className="mb-2">
            <Col lg={8} md={8} sm={12} className="report-text-field-column">
              <TextField
                name="loginID"
                value={userReport.loginID.value}
                onChange={userReportHandler}
                className="text-fields-report"
                placeholder="Login ID"
              />
              <Select
                name="selectRole"
                options={selectRoleReport}
                onChange={reportSelectRoleHandler}
                className="report-select-field-edit"
                value="Select Role"
              />
              <TextField
                name="firstName"
                value={userReport.firstName.value}
                onChange={userReportHandler}
                className="text-fields-report"
                placeholder="First Name"
              />
              <TextField
                name="lastName"
                value={userReport.lastName.value}
                onChange={userReportHandler}
                className="text-fields-report"
                placeholder="Last Name"
              />
            </Col>

            <Col lg={4} md={4} sm={12} className="JS-Security-Datepicker">
              <DatePicker
                // value={value}
                // onChange={setValue}
                {...startDateProps}
                onPropsChange={setStartDateProps}
                showOtherDays={true}
                inputClass="date-picker-left"
                placeholder="Start Date"
              />
              <label className="date-to">to</label>

              <DatePicker
                {...endDateProps}
                onPropsChange={setEndDateProps}
                showOtherDays={true}
                inputClass="date-picker-right"
                placeholder="End Date"
              />
            </Col>
          </Row>

          <Row className="mb-2">
            <Col
              lg={12}
              md={12}
              sm={12}
              className="d-flex justify-content-center mt-3"
            >
              <Button
                icon={<i className="icon-refresh user-reset"></i>}
                text="Reset"
                onClick={resetHandler}
                className="user-report-reset"
              />
            </Col>
          </Row>
        </Paper>

        <Paper className="status-user-panel">
          <Row className="mt-3">
            <Col lg={12} md={12} sm={12}>
              <label className="user-status-heading">Status</label>
            </Col>
          </Row>

          <Row className="mt-3 mb-3">
            <Col lg={12} md={12} sm={12} className="report-btm-button-col">
              <Button
                icon={<i className="icon-download download-btn-icons"></i>}
                text="Access Detail"
                className="report-btm-buttons"
              />
              <Button
                icon={<i className="icon-download download-btn-icons"></i>}
                text="Login History"
                className="report-btm-buttons"
              />
              <Button
                icon={<i className="icon-download download-btn-icons"></i>}
                text="Status Wise"
                className="report-btm-buttons"
              />
              <Button
                icon={<i className="icon-download download-btn-icons"></i>}
                text="Last Login"
                className="report-btm-buttons"
              />
            </Col>
          </Row>
        </Paper>
      </Container>
    </>
  );
};

export default Userreport;
